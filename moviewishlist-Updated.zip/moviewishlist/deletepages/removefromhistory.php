<?php
	if(isset($_GET['id']) && is_numeric($_GET['id'])) {
		require '../components/connection.php';
		$movieid=$_GET['id'];
		$userid=$_COOKIE['user'];

		$query="delete from history where MOVIE=".$movieid." and USER=".$userid;
		mysqli_query($conn, $query);
		header("Location: ../history.php?msg=Movie Removed From the List.");
	}
?>
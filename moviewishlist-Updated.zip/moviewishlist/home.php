<?php
	if(!isset($_COOKIE['user'])){
		header("Location: ./");
	}
	include 'components/header.php';
	require 'components/connection.php';
	$query="select *from user where ID=".$_COOKIE['user'];
	$res=mysqli_query($conn, $query);
	$row=mysqli_fetch_array($res);
?>
<div class="container">
	<center><h1>Welcome <?php echo $row['NAME']; ?></h1></center>
	<div class="errormessage">
		<center>
			<?php
			if(isset($_GET['msg'])){
				echo "<h4><strong>".$_GET['msg']."</strong></h4>";
			}
			?>
		</center>
	</div>
	<hr>
	<?php
		$q="select *from movie where not ID in(select MOVIE from wishlist where USER=".$_COOKIE['user'].") and not ID in(select MOVIE from history where USER=".$_COOKIE['user'].")";
		$rs=mysqli_query($conn, $q);
		if(mysqli_num_rows($rs)==0){
	?>
	<center><h3>No Movies to Show</h3></center>
	<?php
		}
		while($rw=mysqli_fetch_array($rs)){
	?>
	<div class="list-group col-sm-12">
		<div class="list-group-item col-sm-12">
			<div class="col-sm-2">
				<div class="movie-image" style="background-image: url('<?php echo $rw['IMAGE']; ?>');">
				</div>
			</div>
			<div class="col-sm-10">
				<h2><?php echo $rw['TITLE']; ?></h2>
				<p>
					<?php echo $rw['DESCRIPTION']; ?>
				</p>
				<a href="editpages/addtowishlist.php?id=<?php echo $rw['ID']; ?>"><button class="btn btn-default">Add to Wish List</button></a>
				<a href="editpages/addtohistory.php?id=<?php echo $rw['ID']; ?>">
				<button class="btn btn-default">Watched</button>
				</a>
			</div>
		</div>
	</div>
	<?php
		}
	?>
</div>
<?php
	include 'components/footer.php';
?>
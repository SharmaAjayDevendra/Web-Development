<?php
	if(!isset($_COOKIE['user'])){
		header("Location: ./");
	}
	include 'components/header.php';
	include 'components/connection.php';

	$query="select *from history where USER=".$_COOKIE['user'];
	$res=mysqli_query($conn, $query);
?>
<div class="container">
	<h1>Movies watched by me</h1>
	<div class="errormessage">
		<center>
			<?php
				if(isset($_GET['msg'])){
					echo "<h4><strong>".$_GET['msg']."</strong></h4>";
				}
			?>
		</center>
	</div>
	<hr>
	<?php
		if(mysqli_num_rows($res)==0){
	?>
	<center>
		<h3>No Movies to Show</h3>
	</center>
	<?php
		}
		while($row=mysqli_fetch_array($res)){
			$q="select *from movie where ID=".$row['MOVIE'];
			$rs=mysqli_query($conn, $q);
			$rw=mysqli_fetch_array($rs);
	?>
	<div class="list-group col-sm-12">
		<div class="list-group-item col-sm-12">
			<div class="col-sm-2">
				<div class="movie-image" style="background-image: url('<?php echo $rw['IMAGE']; ?>');">
				</div>
			</div>
			<div class="col-sm-10">
				<h2><?php echo $rw['TITLE']; ?></h2>
				<p>
					<?php echo $rw['DESCRIPTION']; ?>
				</p>
				<a href="deletepages/removefromhistory.php?id=<?php echo $rw['ID']; ?>"><button class="btn btn-default">Remove From List</button></a>
			</div>
		</div>
	</div>
	<?php
		}
	?>
</div>
<?php
	include 'components/footer.php';
?>

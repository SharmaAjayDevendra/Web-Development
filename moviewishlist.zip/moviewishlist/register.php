<?php
	if(isset($_COOKIE['user'])){
		header("Location: home.php");
	}
	include 'components/header.php';
?> 
		<center><h1>Sign Up</h1></center>
		<div class="col-sm-5" style="float: none; margin: auto;">
			<form method="post" action="postpages/newuser.php">
				<div class="form-group">
					<input type="text" name="name" class="form-control" placeholder="Enter Name">
				</div>
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="Enter Email">
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Enter Password">
				</div>
				<button class="btn btn-default full">Create Account</button>
			</form><br>
			<h4>Already have an account? <a href="./">Log In</a>.</h4>
		</div>
<?php
	include 'components/footer.php';
?>

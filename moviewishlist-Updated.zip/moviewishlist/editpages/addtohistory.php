<?php
	if(isset($_GET['id']) && is_numeric($_GET['id'])){
		require '../components/connection.php';
		$userid=$_COOKIE['user'];
		$movieid=$_GET['id'];

		$query="insert into history(USER, MOVIE) values($userid, $movieid)";
		mysqli_query($conn, $query);
		header("Location: ../home.php?msg=Movie Added to Watched List");
	}
?>
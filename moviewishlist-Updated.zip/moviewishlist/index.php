<?php
	if(isset($_COOKIE['user'])){
		header("Location: home.php");
	}
	include 'components/header.php';
?>
		<center><h1>Log In</h1></center>
		<center>
			<div class="errormessage">
			<?php 
				if(isset($_GET['msg'])){
					echo $_GET['msg'];
				}
			?>
			</div>
		</center>
		<div class="col-sm-5" style="float: none; margin: auto;">
			<form method="post" action="postpages/postlogin.php">
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="Enter Email" required>
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Enter Password" required>
				</div>
				<button class="btn btn-default full">Log In</button>
			</form><br>
			<h4>Don't have an account? <a href="register.php">Create One</a>.</h4>
		</div>
<?php
	include 'components/footer.php';
?>

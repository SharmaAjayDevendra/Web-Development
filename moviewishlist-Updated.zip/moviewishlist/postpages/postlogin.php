<?php
	if($_SERVER['REQUEST_METHOD']=="POST"){
		require '../components/connection.php';
		$email=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
		$password=trim(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['password'])));

		$query="select *from user where EMAIL='$email' and PASSWORD='$password'";
		$res=mysqli_query($conn, $query);
		if(mysqli_num_rows($res)==0){
			header("Location: ../?msg=Invalid Credentials");
		}else{
			$row=mysqli_fetch_array($res);
			setcookie("user", $row['ID'], time()+3600, "/");
			header("Location: ../home.php");
		}
	}
?>
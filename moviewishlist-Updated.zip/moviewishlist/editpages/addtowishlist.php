<?php
	if(isset($_GET['id']) && is_numeric($_GET['id'])){
		require '../components/connection.php';
		$movieid=$_GET['id'];
		$userid=$_COOKIE['user'];
		$query="insert into wishlist(USER, MOVIE) values($userid, $movieid)";
		mysqli_query($conn, $query);
		header("Location: ../home.php?msg=Movie added to wish list.");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Movie Wish List</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
	<nav class="navbar navbar-inverse navbar-fixed-top">	
		<div class="container">
				<div class="navbar-header">
					<a href="./" class="navbar-brand">Movie Wish List</a>
				</div>
				<ul class="nav navbar-nav navbar-right">
				<?php
					if(!isset($_COOKIE['user'])){
				?>
					<li><a href="./">Log In</a></li>
					<li><a href="register.php">Register</a></li>
				<?php
					}
					if(isset($_COOKIE['user'])){
				?>
					<li><a href="home.php">Home</a></li>
					<li><a href="history.php">My Movies</a></li>
					<li><a href="watchlist.php">Watch List</a></li>
					<li><a href="logout.php">Log Out</a></li>
				<?php
					}
				?>
				</ul>
		</div>
	</nav>
	</header>
	<main>

<?php
	if(!isset($_COOKIE['user'])){
		header("Location: ./");
	}
	include 'components/header.php';
?>
<div class="container">
	<center><h1>Welcome User</h1></center>
</div>
<?php
	include 'components/footer.php';
?>
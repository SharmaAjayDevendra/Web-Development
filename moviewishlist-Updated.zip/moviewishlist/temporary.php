<?php
if($_SERVER['REQUEST_METHOD']=="POST"){
	$conn=mysqli_connect("localhost", "root", "", "moviewishlist");
	$query="insert into movie(TITLE, DESCRIPTION, IMAGE) values('".htmlspecialchars($_POST['title'])."', '".htmlspecialchars($_POST['description'])."', '".htmlspecialchars($_POST['image'])."')";
	mysqli_query($conn, $query);
}
?>

<form method="post" action="temporary.php">
	<input type="text" placeholder="Title of Movie" name="title"><br><br>
	<input type="text" placeholder="Description of Movie" name="description"><br><br>
	<input type="text" placeholder="Image" name="image"><br><br>
	<button>Submit</button>
</form>

<?php
	$conn=mysqli_connect("localhost", "root", "", "moviewishlist");
	$query="select *from movie";
	$res=mysqli_query($conn, $query);
	while($row=mysqli_fetch_array($res)){
		echo $row['TITLE']."<br>";
	}
?>
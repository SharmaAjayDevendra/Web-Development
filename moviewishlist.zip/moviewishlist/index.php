<?php
	if(isset($_COOKIE['user'])){
		header("Location: home.php");
	}
	include 'components/header.php';
?>
		<center><h1>Log In</h1></center>
		<div class="col-sm-5" style="float: none; margin: auto;">
			<form>
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="Enter Email">
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Enter Password">
				</div>
				<button class="btn btn-default full">Log In</button>
			</form><br>
			<h4>Don't have an account? <a href="register.php">Create One</a>.</h4>
		</div>
<?php
	include 'components/footer.php';
?>

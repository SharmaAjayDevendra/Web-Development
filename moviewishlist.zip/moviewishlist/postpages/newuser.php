<?php
	if($_SERVER['REQUEST_METHOD']=="POST"){
		require '../components/connection.php';
		$name=trim(htmlspecialchars($_POST['name']));
		$email=trim(htmlspecialchars($_POST['email']));
		$password=trim(htmlspecialchars($_POST['password']));

		$query="select *from user where EMAIL='$email'";
		$res=mysqli_query($conn, $query);
		if(mysqli_num_rows($res)==1){
			header("Location: ../register.php?msg=Account with this email address already exists.");
		}else{
			$query="insert into user(NAME, EMAIL, PASSWORD) values('$name','$email', '$password')";
			$res=mysqli_query($conn, $query);

			$id=mysqli_insert_id($conn);
			setcookie("user", $id, time()+3600, "/");
			header("Location: ../home.php");			
		}
	}
?>
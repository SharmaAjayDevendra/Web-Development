	</main>
	<footer>		
		<center>
			&copy; Copyright <?php echo date('Y'); ?> All Rights Reserved.
		</center>
	</footer>
</body>
</html>
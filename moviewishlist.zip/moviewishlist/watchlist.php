<?php
	if(!isset($_COOKIE['user'])){
		header("Location: ./");
	}
	include 'components/header.php';
?>
<div class="container">
	<h1>Movies in my Wish List</h1>
	<hr>
	<div class="list-group col-sm-12">
		<div class="list-group-item col-sm-12">
			<div class="col-sm-2">
				<img src="https://dummyimage.com/300x300/000/fff" class="img-responsive">
			</div>
			<div class="col-sm-10">
				<h2>Chhichhore</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
				</p>
			</div>
		</div>
	</div>
</div>
<?php
	include 'components/footer.php';
?>
